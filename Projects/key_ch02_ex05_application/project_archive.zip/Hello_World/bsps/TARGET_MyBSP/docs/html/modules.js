var modules =
[
    [ "Error Codes", "group__group__bsp__errors.html", "group__group__bsp__errors" ],
    [ "Functions", "group__group__bsp__functions.html", "group__group__bsp__functions" ],
    [ "Functions", "group__group__bsp__dsram__functions.html", "group__group__bsp__dsram__functions" ],
    [ "Pin Mappings", "group__group__bsp__pins.html", "group__group__bsp__pins" ],
    [ "Pin States", "group__group__bsp__pin__state.html", "group__group__bsp__pin__state" ]
];